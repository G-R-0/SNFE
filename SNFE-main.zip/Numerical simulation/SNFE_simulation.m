clear;
clc;
close all;
%%
e=exp(1);
for i=1:11  %network node
    X(i,1)=rand()*(5-1)+1;
end
delta_t=1;
L=2100;       
N=round(L/delta_t);  
ts=zeros(N,1);
sigma=0.01;  %noise
es=0.000000001;
s=zeros(1,27);
s(1)=-0.5;
s(2)=-0.475;
s(3)=-0.45;
s(4)=-0.4;
s(5)=-0.375;
s(6)=-0.35;
s(7)=-0.325;
s(8)=-0.3;
s(9)=-0.275;
s(10)=-0.25;
s(11)=-0.225;
s(12)=-0.2;
s(13)=-0.175;
s(14)=-0.15;
s(15)=-0.125;
s(16)=-0.1;
s(17)=-0.08;
s(18)=-0.05;
s(19)=-0.02;
s(20)=-0.0001;
s(21)=0.02;
s(22)=0.05;
s(23)=0.08;
s(24)=0.1;
s(25)=0.15;
s(26)=0.18;
s(27)=0.22;
s(28)=0.25;
D= [-1 0 0 1 0 0 0 0 0 0 0;...
    -1 -1 0 0 0 0 0 0 0 0 0;...
    1 0 1 0 0 0 0 0 0 0 0;...
    -1 0 0 -1 0 0 0 0 0 0 0;...
    0 -1 1 0 -1 1 0 0 0 0 0;...
    0 0 0 0 1 -1 1 0 0 0 0 ;...
    0 0 0 0 0 1 -1 0 0 0 0 ;...
    0 0 0 0 1 0 0 -1 0 0 0
    0 0 0 0 1 0 0 0 -1 0 0
    0 0 0 0 1 0 0 0 0 -1 0
    0 0 0 0 1 0 0 0 0 0 -1]; 
sample_num=1;
CC=zeros(11,4,sample_num);   
CC1=zeros(11,4,28);         
ss=-0.50:5/2700:-0.45;
%%
%network
[Net,gene_Netnames]=xlsread('Network.csv');
network = {};
for i = 1:length(gene_Netnames)
    current_gene = gene_Netnames{i};
    for j = 1:length(Net)
        if Net(i, j) ~= 0
            network{end+1, 1} = current_gene;
            network{end, 2} = gene_Netnames{j};
        end
    end
end
[data0,node]=xlsread('node.csv');
%%
%mix samples
for ll=1:28
    qq(ll)=0.96^(1/abs(ss(ll)));  
    E=[-2/11*qq(ll) 0 0 0 0 0 0 0 0 0 0;...
            0 -4/11 0 0 0 0 0 0 0 0 0;...
            0  0 -6/11 0 0 0 0 0 0 0 0;...
            0 0 0 -8/11 0 0 0 0 0 0 0;...
            0 0 0 0 -10/11 0 0 0 0 0 0;...
            0 0 0 0 0 -12/11 0 0 0 0 0;...
            0 0 0 0 0 0 -14/11 0 0 0 0;...
            0 0 0 0 0 0 0 -16/11 0 0 0;...
            0 0 0 0 0 0 0 0 -18/11 0 0
            0 0 0 0 0 0 0 0 0 -20/11 0
            0 0 0 0 0 0 0 0 0 0 -22/11];
    J=D*E*inv(D);
    for i=1:N-1;
        ts(i+1)=ts(i)+delta_t;  
        eJ=e^(J*delta_t);
        for jj=1:11;
            X(jj,i+1)=eJ(jj,:)*X(:,i)+sigma*normrnd(0,1)*delta_t;
        end
    end
    CC1(:,1,ll)=X(:,2000); 
end
stage=28;
pprofile=(reshape(CC1(:,1,:),11,28));
pprofile=abs(pprofile);
psize=size(pprofile); 
tempcase=zeros(11,28); 
patients_num=28;
tempcase(:,1:patients_num)=pprofile(:,1:psize(2)); 
%%
% Calculate the network flow entropy 
for T=1:8
    for t=1:28
        q(t)=0.96^(1/abs(s(t)));
        E=[-2/11*q(t) 0 0 0 0 0 0 0 0 0 0;...
            0 -4/11 0 0 0 0 0 0 0 0 0;...
            0  0 -6/11 0 0 0 0 0 0 0 0;...
            0 0 0 -8/11 0 0 0 0 0 0 0;...
            0 0 0 0 -10/11 0 0 0 0 0 0;...
            0 0 0 0 0 -12/11 0 0 0 0 0;...
            0 0 0 0 0 0 -14/11 0 0 0 0;...
            0 0 0 0 0 0 0 -16/11 0 0 0;...
            0 0 0 0 0 0 0 0 -18/11 0 0
            0 0 0 0 0 0 0 0 0 -20/11 0
            0 0 0 0 0 0 0 0 0 0 -22/11];
        J=D*E*inv(D);        
        for k=1:sample_num
            for i=1:N-1
                ts(i+1)=ts(i)+delta_t;
                eJ=e^(J*delta_t);
                for jj=1:11
                    X(jj,i+1)=eJ(jj,:)*X(:,i)+sigma*normrnd(0,1)*delta_t;
                end
            end
            CC(:,t,k)=X(:,2000);
        end  
    TC(:,t)=reshape(CC(:,t,:),11,sample_num);
    tempcase(:,patients_num)=TC(:,t); 
    tempcase=abs(tempcase);
    msize=size(tempcase);
   edge_source=network(:,1);
   edge_target=network(:,2);
   node1=unique(network(:,1));
   es=0.00000001;
         for na=1:length(node1)
             edges_list=[];
             [cencter_liang,cencter_idd]= find(ismember(node,node1(na)));
             if isempty(cencter_liang)
                 Land_entropy(na,t)=0;
                 Land_entropy_1(na,t)=0;
                 Land_entropy_mix(na,t)=0;
                 Land_entropy_1_mix(na,t)=0;
                 continue;
             else
                 [liang,nei_idd]= find(ismember(edge_source,node1(na)));
                 nei_gene=edge_target(liang);
                 e=0;
                 for n=1:length(nei_gene)
                     [nei_liang,nie_idd]= find(ismember(node,nei_gene(n)));
                     if ~isempty(nei_liang)
                         e=e+1;
                         edges_list(e,:)=[cencter_liang nei_liang];
                     end
                 end
                 [liang_1,nei_idd_1]= find(ismember(edge_target,node1(na)));
                 nei_gene_1=edge_source(liang_1);
                 e1=0;
                 for n=1:length(nei_gene_1)
                     [nei_liang_1,nie_idd_1]= find(ismember(node,nei_gene_1(n)));
                     if ~isempty(nei_liang_1)
                         e1=e1+1;
                         edges_list_1(e1,:)=[cencter_liang nei_liang_1];
                     end
                 end
             end
            if e<2
                Land_entropy(na,t)=0;
                Land_entropy_1(na,t)=0;
                continue;
            end
            nn=0;
            for i=1:e
                curr_pcc(na,t,i)=abs(corr(tempcase(edges_list(i,1),:)',tempcase(edges_list(i,2),:)'));
                curr_std(na,t,i)=abs(std(tempcase(edges_list(i,1),:)',tempcase(edges_list(i,2),:)'));
                w_pcc(na,t,i)=abs(0.5 * log((1+curr_pcc(na,t,i))/(1-curr_pcc(na,t,i))));
                temp_add_onecase1=[tempcase(edges_list(i,1),:),reshape(tempcase(edges_list(i,1)),1,1)];
                temp_add_onecase2=[tempcase(edges_list(i,2),:),reshape(tempcase(edges_list(i,2)),1,1)];
                curr_pcc_add_onecase(na,t,i)=abs(corr(temp_add_onecase1',temp_add_onecase2'));
                curr_std_add_onecase(na,t,i)=std(corr(temp_add_onecase1',temp_add_onecase2'));
                w_pcc_add_onecase(na,t,i)=abs(0.5 * log((1+curr_pcc_add_onecase(na,t,i))/(1-curr_pcc_add_onecase(na,t,i))));
                delt(na,t,i)=abs(w_pcc_add_onecase(na,t,i)-w_pcc(na,t,i));
                delt_std(na,t,i)=abs(curr_std_add_onecase(na,t,i)-curr_std(na,t,i));
            end
            delt_s(na,t)=sum(delt(na,t,:));
            for i=1:e
            delt_pcc(na,t,i)=delt(na,t,i)/(delt_s(na,t)+es);
            Land_entropy(na,t,i)=-delt_std(na,t,i).*((tempcase(na,t).*delt_pcc(na,t,i).*log(abs(tempcase(na,t).*(delt_pcc(na,t,i)+es)))));
            end
            Land_entropy_sum(na,t)=sum(Land_entropy(na,t,:));
            for i=1:e1
                curr_pcc_1(na,t,i)=abs(corr(tempcase(edges_list_1(i,1),:)',tempcase(edges_list_1(i,2),:)'));
                curr_std_1(na,t,i)=abs(std(tempcase(edges_list_1(i,1),:)',tempcase(edges_list_1(i,2),:)'));
                w_pcc_1(na,t,i)=abs(0.5 * log((1+curr_pcc_1(na,t,i))/(1-curr_pcc_1(na,t,i))));
                temp_add_onecase_1=[tempcase(edges_list_1(i,1),:),reshape(tempcase(edges_list_1(i,1)),1,1)];
                temp_add_onecase_2=[tempcase(edges_list_1(i,2),:),reshape(tempcase(edges_list_1(i,2)),1,1)];
                curr_pcc_add_onecase_2(na,t,i)=abs(corr(temp_add_onecase_1',temp_add_onecase_2'));
                curr_std_add_onecase_2(na,t,i)=abs(std(temp_add_onecase_1',temp_add_onecase_2'));
                w_pcc_add_onecase_2(na,t,i)=abs(0.5 * log((1+curr_pcc_add_onecase_2(na,t,i))/(1-curr_pcc_add_onecase_2(na,t,i))));
                delt_1(na,t,i)=abs(w_pcc_add_onecase_2(na,t,i)-w_pcc_1(na,t,i));
                delt_1_std(na,t,i)=abs(curr_std_add_onecase_2(na,t,i)-curr_std_1(na,t,i));
            end
                delt_1_s(na,t)=sum(delt_1(na,t,:));
                for i=1:e1
                 delt_pcc_1(na,t,i)=(delt_1(na,t,i))/(delt_1_s(na,t)+es);
                Land_entropy_1(na,t,i)=-delt_1_std(na,t,i).*((tempcase(na,t).*delt_pcc_1(na,t,i).*log(abs(tempcase(na,t).*(delt_pcc_1(na,t,i)+es)))));
                end
           Land_entropy_1_sum(na,t)=sum(Land_entropy_1(na,t,:));
           Land_entropy_total_sum(na,t)=Land_entropy_sum(na,t)+Land_entropy_1_sum(na,t); 
         end
         SNFE_entropy(t)=sum(Land_entropy_total_sum(:,t));
    end
end
SNFE=SNFE_entropy/T;
%%
figure1=figure('NumberTitle', 'off', 'Name', 'Simulation');
axes1 = axes('Parent',figure1);
plot(s(1:28),SNFE,'r-*','LineWidth',2.5);
line([s(20) s(20)],[0 SNFE(20)],'linestyle','--','Color','m','LineWidth',1.5);
xlim(axes1,[-0.5 0.25]);
%ylim(axes1,[0 0.11]);
box(axes1,'on');
xlabel('Parameter p');
ylabel('SNFE Score');
legend('sigma=0.1');


