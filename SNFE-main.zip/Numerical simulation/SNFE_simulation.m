clear;
clc;
close all;
%%
for i=1:11  %network node
    X(i,1)=rand()*(5-1)+1;
end
delta_t=1;
L=2100;       
N=round(L/delta_t);  
ts=zeros(N,1);
sigma=0.05;  %noise
es=0.00000001;
s=zeros(1,28);
s(1)=-0.5;
s(2)=-0.475;
s(3)=-0.45;
s(4)=-0.4;
s(5)=-0.375;
s(6)=-0.35;
s(7)=-0.325;
s(8)=-0.3;
s(9)=-0.275;
s(10)=-0.25;
s(11)=-0.225;
s(12)=-0.2;
s(13)=-0.175;
s(14)=-0.15;
s(15)=-0.125;
s(16)=-0.1;
s(17)=-0.08;
s(18)=-0.05;
s(19)=-0.02;
s(20)=-0.0001;
s(21)=0.02;
s(22)=0.05;
s(23)=0.08;
s(24)=0.1;
s(25)=0.15;
s(26)=0.18;
s(27)=0.22;
s(28)=0.25;
D= [-1 0 0 1 0 0 0 0 0 0 0;...
    -1 -1 0 0 0 0 0 0 0 0 0;...
    1 0 1 0 0 0 0 0 0 0 0;...
    -1 0 0 -1 0 0 0 0 0 0 0;...
    0 -1 1 0 -1 1 0 0 0 0 0;...
    0 0 0 0 1 -1 1 0 0 0 0 ;...
    0 0 0 0 0 1 -1 0 0 0 0 ;...
    0 0 0 0 1 0 0 -1 0 0 0
    0 0 0 0 1 0 0 0 -1 0 0
    0 0 0 0 1 0 0 0 0 -1 0
    0 0 0 0 1 0 0 0 0 0 -1]; 
sample_num=1;
CC=zeros(11,28,sample_num);   
CC1=zeros(11,4,28);         
ss=-0.50:5/2700:-0.45;
%%
%network
scriptDir = fileparts(mfilename('fullpath'));
nodeRows = regexp(strtrim(fileread(fullfile(scriptDir,'node.csv'))), ...
    '\r\n|\n|\r','split');
nodeNames = cellfun(@(row) strtok(row,','),nodeRows(:),'UniformOutput',false);
networkData = textscan(fileread(fullfile(scriptDir,'Network.csv')), ...
    ['%s',repmat('%f',1,numel(nodeNames))],'Delimiter',',','CollectOutput',true);
networkNames = networkData{1};
net = networkData{2};
[matched, networkOrder] = ismember(nodeNames,networkNames);
assert(size(net,1)==size(net,2) && size(net,1)==numel(nodeNames) && ...
    all(isfinite(net(:))) && all(matched) && ...
    numel(unique(networkOrder))==numel(nodeNames), ...
    'Network.csv and node.csv must identify the same simulation nodes.');
adjacency = net(networkOrder,networkOrder)~=0;
node1=nodeNames;
%%
%mix samples
for ll=1:28
    qq(ll)=0.96^(1/abs(ss(ll)));  
    E=[-2/11*qq(ll) 0 0 0 0 0 0 0 0 0 0;...
            0 -4/11 0 0 0 0 0 0 0 0 0;...
            0  0 -6/11 0 0 0 0 0 0 0 0;...
            0 0 0 -8/11 0 0 0 0 0 0 0;...
            0 0 0 0 -10/11 0 0 0 0 0 0;...
            0 0 0 0 0 -12/11 0 0 0 0 0;...
            0 0 0 0 0 0 -14/11 0 0 0 0;...
            0 0 0 0 0 0 0 -16/11 0 0 0;...
            0 0 0 0 0 0 0 0 -18/11 0 0
            0 0 0 0 0 0 0 0 0 -20/11 0
            0 0 0 0 0 0 0 0 0 0 -22/11];
    J=D*E/D;
    eJ=expm(J*delta_t);
    for i=1:N-1;
        ts(i+1)=ts(i)+delta_t;  
        X(:,i+1)=eJ*X(:,i)+sigma*randn(11,1)*delta_t;
    end
    CC1(:,1,ll)=X(:,2000); 
end
pprofile=abs(reshape(CC1(:,1,:),11,28));
% Use one reference-derived scale for the reference and all query samples.
positiveReference=pprofile(pprofile>0);
assert(~isempty(positiveReference),'The reference has no positive expression.');
expressionScale=median(positiveReference);
referenceProfiles=pprofile./(pprofile+expressionScale);
%%
% Calculate the network flow entropy 
repeatCount=30;
queryCount=repeatCount*sample_num;
queryProfiles=zeros(11,28,queryCount);
for T=1:repeatCount
    for t=1:28
        q(t)=0.96^(1/abs(s(t)));
        E=[-2/11*q(t) 0 0 0 0 0 0 0 0 0 0;...
            0 -4/11 0 0 0 0 0 0 0 0 0;...
            0  0 -6/11 0 0 0 0 0 0 0 0;...
            0 0 0 -8/11 0 0 0 0 0 0 0;...
            0 0 0 0 -10/11 0 0 0 0 0 0;...
            0 0 0 0 0 -12/11 0 0 0 0 0;...
            0 0 0 0 0 0 -14/11 0 0 0 0;...
            0 0 0 0 0 0 0 -16/11 0 0 0;...
            0 0 0 0 0 0 0 0 -18/11 0 0
            0 0 0 0 0 0 0 0 0 -20/11 0
            0 0 0 0 0 0 0 0 0 0 -22/11];
        J=D*E/D;
        eJ=expm(J*delta_t);
        for k=1:sample_num
            for i=1:N-1
                ts(i+1)=ts(i)+delta_t;
                X(:,i+1)=eJ*X(:,i)+sigma*randn(11,1)*delta_t;
            end
            CC(:,t,k)=X(:,2000);
            queryExpression=abs(CC(:,t,k));
            queryProfiles(:,t,(T-1)*sample_num+k)= ...
                queryExpression./(queryExpression+expressionScale);
        end  
    end
end

SNFE=zeros(1,28);
nodeStageScores=zeros(11,28);
nodeCellScores=zeros(11,28,queryCount);
for t=1:28
    tempcase=reshape(queryProfiles(:,t,:),11,queryCount);
    [SNFE(t),nodeStageScores(:,t),cellScores]= ...
        snfe_stage_scores(referenceProfiles,tempcase,adjacency,es);
    nodeCellScores(:,t,:)=reshape(cellScores,11,1,queryCount);
end
%%
figure1=figure('NumberTitle', 'off', 'Name', 'Simulation');
axes1 = axes('Parent',figure1);
plot(s(1:28),SNFE,'r-*','LineWidth',2.5);
line([s(20) s(20)],[0 SNFE(20)],'linestyle','--','Color','m','LineWidth',1.5);
xlim(axes1,[-0.5 0.25]);
%ylim(axes1,[0 0.11]);
box(axes1,'on');
xlabel('Parameter p');
ylabel('SNFE Score');
legend(['sigma=' num2str(sigma)]);


