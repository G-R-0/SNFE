clear
[data,gene_names]=xlsread('neg_NOR_scale_data1.csv');
c=[];
alpha=0.01; 
boxsize=0.1;
weighted=0;
csn = csnet(data,c,alpha,boxsize,weighted);
















