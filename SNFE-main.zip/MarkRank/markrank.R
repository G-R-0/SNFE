#NOR
#rm(list=ls(all=TRUE))
setwd("/lustre/home/gaor/DNB/MarkRank")
source("/lustre/home/gaor/DNB/MarkRank/Functions/read_net.R")
source("/lustre/home/gaor/DNB/MarkRank/Functions/solve_equation.R")
source("/lustre/home/gaor/DNB/MarkRank/Functions/NET2_compute.r")
source("/lustre/home/gaor/DNB/MarkRank/Functions/analysis.r")
options(scipen=999)
library(Matrix)
library(mpmi)
choose_dataset <- "NOR"									
CSN_net <- read_net("/lustre/home/gaor/DNB/MarkRank/NOR/result_gene_names.txt",usename=TRUE)	
CSN_net$size										
label <- read.table("/lustre/home/gaor/DNB/MarkRank/NOR/neg_NOR_scale_data1_label.txt",header=TRUE)
dataset_all <- read.table("/lustre/home/gaor/DNB/MarkRank/NOR/neg_NOR_scale_data1.txt",header=TRUE)											
dataset_all <- scale(dataset_all)

common <- intersect(CSN_net$node,colnames(dataset_all))					# Common genes in CSN network and expression dataset before CCA refinement.
adjacent <- as(CSN_net$adj_matrix,"dgCMatrix")
common_adj <- adjacent[common,common]
Nodes_length <- NULL													# Number of nodes in each connected component.
for (i in 1:length(result$con_component)){
	Nodes_length[i] <- length(result$con_component[[i]])		
}
Nodes_small <- NULL														# Gene symbols in small connected components.
for (i in 2:length(result$con_component)){
	Nodes_small <- c(Nodes_small,result$con_component[[i]])
}
Nodes   <- setdiff(colnames(common_adj),Nodes_small)					# Genes in the largest connected component is selected.
Net_adj <- common_adj[Nodes,Nodes]										# CSN ADJACENT MATRIX after refined and this network is used for further analysis.
Dataset <- dataset_all[,Nodes]											# GENE EXPRESSION MATRIX of selected genes is used for further analysis.
dim(Dataset)


# TASK2.1: Compute the MarkRank and NetRank scores for each gene.
loadin <- FALSE															# loadin set TRUE after first run the code.
if (loadin == TRUE){
	load(paste("real dataset",choose_dataset,"A1.RData",sep="/"))		# Probability transition matrix of A1, CSN network information.
	load(paste("real dataset",choose_dataset,"A2.RData",sep="/"))		# Probability transition matrix of A2, Discriminative potential network information.
}else{
	NET1 <- Net_adj
	D1 <- diag(1/rowSums(NET1))
	A1 <- t(NET1)%*%D1
	save(NET1,file=paste("real dataset",choose_dataset,"NET1.RData",sep="/"))
	save(A1,file=paste("real dataset",choose_dataset,"A1.RData",sep="/"))

	D2 <- Matrix(0,length(Nodes),length(Nodes),sparse=TRUE)
	system.time(NET2 <- NET2_compute(Dataset,label,prints=TRUE))
	diag(D2) <- 1/rowSums(NET2)
	A2 <- t(NET2)%*%D2
	save(NET2,file=paste("real dataset",choose_dataset,"NET2.RData",sep="/"))
	save(A2,file=paste("real dataset",choose_dataset,"A2.RData",sep="/"))
}
# 写入 CSV 文件
dense_matrix <- as.matrix(NET2)
write.csv(dense_matrix, file = paste("real dataset", choose_dataset, paste(choose_dataset, "NET2.csv", sep = "_"), sep = '/'), row.names = TRUE)


label <- rep(0, 20)
label[8:12] <- 1
label[16:20] <- 2
MI  <- mminjk(Dataset, as.matrix(as.numeric(label)), level = 0L, na.rm = FALSE)
PCC <- NULL																# Use the absolute value of Pearson correlation coefficient(PCC) as the prior information.
for (i in 1:ncol(Dataset)){
	PCC[i] <- cor(Dataset[,i],label,method="pearson")
}
p <- 10000
score <- solve_equation(as.matrix(A1),as.matrix(A2),E_value=abs(PCC),alpha=0.8,lamda=0.2,PCC=PCC,MI=MI,Plot=FALSE)
s1 <- sort(score$MarkRank,decreasing=TRUE,index.return=TRUE)			# MarkRank method.
s2 <- sort(score$NetRank,decreasing=TRUE,index.return=TRUE)				# NetRank method.
scores1 <- matrix(0,100,2)
scores2 <- matrix(0,100,2)
scores1[,1] <- colnames(Dataset)[s1$ix[1:100]]
scores1[,2] <- s1$x[1:100]
scores2[,1] <- colnames(Dataset)[s2$ix[1:100]]
scores2[,2] <- s2$x[1:100]
length(intersect(scores1[,1],scores2[,1]))



# TASK2.2: Obtain the top gene list for each prioritization methods.
value <- list()															# Obtain the top gene identified via each method.
for (v in 1:8){								
	value[[v]] <- 0														# Each alternative method.
}
value[[1]] <- as.vector(mminjk(as.matrix(Dataset), as.matrix(label), level = 0L, na.rm = FALSE))	# Mutual information
for (p in 1:ncol(Dataset)){
	t1  <- Dataset[which(label==0),p]
	t2  <- Dataset[which(label==1),p]
	value[[2]][p] <- t.test(t1,t2)$p.value								# Student t-test p-value.
	value[[3]][p] <- t.test(t1,t2)$statistic							# Student t-test statistic.
	value[[4]][p] <- cor(Dataset[,p],as.numeric(label),method="pearson")# Pearson  correlation coefficient.
	value[[5]][p] <- cor(Dataset[,p],as.numeric(label),method="spearman")# Spearman correlation coefficient.
	value[[6]][p] <- mean(t1)/mean(t2)									# Fold change ratio.
}
score <- solve_equation(A1,A2,E_value=abs(value[[4]]),alpha=0.8,lamda=0.2,Plot=FALSE)		
value[[7]] <- score$NetRank												# NetRank score.												
value[[8]] <- score$MarkRank 											# MarkRank score.
svalue <- list()
identify_matrix <- matrix(0,ncol(Dataset),16,dimnames=list(1:ncol(Dataset),
c("MI","value1","t.p-value","value2","t.statistic","value3","PCC","value4","SCC","value5","FC","value6","NetRank","value7","MarkRank","value8")))
for (v in 1:8){
	names(value[[v]]) <- colnames(Dataset)
	if (v == 2){
		svalue[[v]] <- sort(abs(value[[v]]),decreasing=FALSE,index.return=TRUE)
	}else{
		svalue[[v]] <- sort(abs(value[[v]]),decreasing=TRUE,index.return=TRUE)		# Sorted value of each alternative method.
	}
	identify_matrix[,2*v-1] <- names(svalue[[v]]$x)
	identify_matrix[,2*v] <- value[[v]][svalue[[v]]$ix]
}
write.table(identify_matrix,file=paste("Top_gene_summary_",choose_dataset,".txt",sep=''),row.names=FALSE,quote=FALSE)



# TASK2.3: Summary of related statistical properties of genes identified via MarkRank.
load(paste("real dataset",choose_dataset,"NET1.RData",sep="/"))			# Adjacent matrix of network1.
load(paste("real dataset",choose_dataset,"NET2.RData",sep="/"))			# Adjacent weighted matrix of discriminative potential network2.
degs <- function(x){
	sum(x != 0)
}
p_value <- NULL															# Histogram of p-value derived from student t-test for single gene expression.
for (i in 1:ncol(Dataset)){
	p_value[i]  <- t.test(Dataset[which(label==0),i],Dataset[which(label==1),i])$p.value
}
Deg1  <- apply(NET1,1,sum)												# Degree in NET1.
Deg21 <- apply(NET2,1,degs)												# Out degrees in NET2.
Deg2  <- apply(NET2,1,sum)												# Out weights in NET2.
Deg31 <- apply(NET2,2,degs)												# In  degrees in NET2.
Deg3  <- apply(NET2,2,sum)												# In  weights in NET2.
rank1  <- sort(Deg1 ,decreasing=TRUE)
rank21 <- sort(Deg21,decreasing=TRUE)
rank2  <- sort(Deg2 ,decreasing=TRUE)
rank31 <- sort(Deg31,decreasing=TRUE)
rank3  <- sort(Deg3 ,decreasing=TRUE)
MIs <- sort(MI,decreasing=TRUE)
PCs <- sort(abs(PCC),decreasing=TRUE)
Deg1_rank <- NULL;Deg21_rank <- NULL;Deg2_rank <- NULL;Deg31_rank <- NULL;Deg3_rank <- NULL;MuIn_rank <- NULL;PCCo_rank <- NULL;Stud_rank <- NULL
for (i in 1:ncol(Dataset)){
	Deg1_rank[i]  <- min(which(rank1 == Deg1[s1$ix[i]]))
	Deg21_rank[i] <- min(which(rank21 == Deg21[s1$ix[i]]))
	Deg2_rank[i]  <- min(which(rank2 == Deg2[s1$ix[i]]))
	Deg31_rank[i] <- min(which(rank31 == Deg31[s1$ix[i]]))
	Deg3_rank[i]  <- min(which(rank3 == Deg3[s1$ix[i]]))
	MuIn_rank[i]  <- min(which(MIs == MI[s1$ix[i]]))
	PCCo_rank[i]  <- min(which(PCs == abs(PCC[s1$ix[i]])))
}
set1 <- colnames(Dataset)[s1$ix]
Summary <- matrix(0,ncol(Dataset),9,dimnames=list(set1,c("MarkRank","Degree","Out-Degree","Out-weight","In-Degree","In-weight","MI","PCC","t-test p")))
Summary[,1] <- substr(s1$x[1:ncol(Dataset)],1,10)
Summary[,2] <- paste(substr(Deg1[s1$ix],1,8)," (",Deg1_rank,")",sep='')
Summary[,3] <- paste(substr(Deg21[s1$ix],1,8)," (",Deg21_rank,")",sep='')
Summary[,4] <- paste(substr(Deg2[s1$ix],1,8)," (",Deg2_rank,")",sep='')
Summary[,5] <- paste(substr(Deg31[s1$ix],1,8)," (",Deg31_rank,")",sep='')
Summary[,6] <- paste(substr(Deg3[s1$ix],1,8)," (",Deg3_rank,")",sep='')
Summary[,7] <- paste(substr(MI[s1$ix],1,8)  ," (",MuIn_rank,")",sep='')
Summary[,8] <- paste(substr(PCC[s1$ix],1,8) ," (",PCCo_rank,")",sep='')
Summary[,9] <- p_value[s1$ix[1:ncol(Dataset)]]
Summary1 <- as.data.frame(Summary)
write.csv(Summary1,file=paste("real dataset",choose_dataset,paste(choose_dataset,"Summary.csv",sep="_"),sep='/'),quote=FALSE)
