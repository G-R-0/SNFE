sort_subnets <- function(a,size){	
	# Input variable a is the result of function best_subnets.

	all_score <- NULL
	subsize   <- NULL	# Record the length of each sub-list. e.g. the number of k-node sub-network in original network. k=1,2,...size.
	for (i in 1:size){
		all_score  <- c(all_score,a$results[[i]])
		subsize[i] <- length(a$results[[i]]) 
	}
	score_sort  <- sort(all_score,decreasing=T,index.return=T)
	subnet_sort <- matrix(NA,length(score_sort$x),size)
	for (i in 1:length(score_sort$x)){
	
		tmp <- score_sort$ix[i]
		for (j in 1:size){
			if (tmp > subsize[j]){
				tmp <- tmp - subsize[j]
			}else{
				k <- j
				break
			}
		}
		subnet_sort[i,1:k] <- a$subnets[[k]][tmp,]
	}
	interesting <- cbind(subnet_sort,score_sort$x)
	return(interesting)
}
