NET2_compute <- function(dataset, label, prints=FALSE){
	library(mpmi)
	library(Matrix)
	
	l <- ncol(dataset)
	MI1 <- mminjk(dataset, as.matrix(as.numeric(label)), level = 0L, na.rm = FALSE)
	MI2 <- Matrix(0,l,l,dimnames=list(colnames(dataset),colnames(dataset)),sparse=TRUE)
	for (i in 1:l){
		if (prints == TRUE){
			if (i%%10 == 0){
				print(i)
			}
		}
		dataset_tmp <- (dataset[,i:l] + dataset[,i])/sqrt(2)
		MI2[i:l,i] <- mminjk(as.matrix(dataset_tmp), as.matrix(as.numeric(label)), level = 0L, na.rm = FALSE)
	}
	MI2 <- MI2 + t(MI2)
	diag(MI2) <- MI1
	
	NET2 <- MI2-as.numeric(MI1)
	ind <- which(NET2 <= 0)
	NET2[ind] <- 0
	NET2 <- as(NET2,"dgCMatrix")
	
	return(NET2)
}
