search2net <- function(filename,size1,size2){
	# This function search two sub-networks from the original holistic network. The two subnets do not connected by each other.
	# filename : The edge links of target network and should be the input of function read_net.
	
	source("../Codes/Functions/neighbour_search.R")
	source("../Codes/Functions/connected_component.R")

	net_info <- read_net(filename)									# The full information of current holistic network extracted from original PPI network.
	con_size <- 0
	while (max(con_size) < size2){
		sub1 <- search_net(net_info,node_size=size1,ori_name=TRUE)	# Edge links of subnetwork1.
		node_set1 <- unique(c(sub1[,1],sub1[,2]))
		neig_set1 <- as.numeric(neighbour_search(net_info$adj_matrix,node_set1,1)$neighb_set1)

		tmp_adj <- net_info$adj_matrix[-c(node_set1,neig_set1),-c(node_set1,neig_set1)]		# The remaining network deleting nodes in subnetwork1 and its neighbours.
		tmp_adj[upper.tri(tmp_adj)] <- 0
		index  <- which(tmp_adj == 1,arr.ind=TRUE)
		index2 <- index												# Edge links of remaining network.
		for (i in 1:nrow(index)){
			index2[i,1] <- as.numeric(rownames(tmp_adj)[index[i,1]])
			index2[i,2] <- as.numeric(rownames(tmp_adj)[index[i,2]])
		}
		rownames(index2) <- NULL
		colnames(index2) <- NULL

		net_info2 <- read_net(index2,usename=TRUE)					# The full information of remaining network.
		con_result <- connected_component(net_info2$adj_matrix)		# Using the	largest connected component to extract the second network.
		con_size   <- NULL 
		for (i in 1:length(con_result$con_component)){
			con_size[i] <- length(con_result$con_component[[i]])
		}
		if (max(con_size) > size2){
			ind <- which.max(con_size)
			nodes <- con_result$con_component[[ind]]
			
			tmp_adj <- net_info2$adj_matrix[nodes,nodes]
			tmp_adj[upper.tri(tmp_adj)] <- 0
			index  <- which(tmp_adj == 1,arr.ind=TRUE)
			index2 <- index											# Edge links of remaining network.
			for (i in 1:nrow(index)){
				index2[i,1] <- as.numeric(rownames(tmp_adj)[index[i,1]])
				index2[i,2] <- as.numeric(rownames(tmp_adj)[index[i,2]])
			}
			rownames(index2) <- NULL
			colnames(index2) <- NULL

			net_info3 <- read_net(index2,usename=TRUE)	
			sub2  <- search_net(net_info3,node_size=size2,ori_name=TRUE)# Edge links of subnetwork2.
			node_set2 <- unique(c(sub2[,1],sub2[,2]))
		}
	}
	return(list(net1=node_set1,net2=node_set2))
}
