get_two_net <- function(sub_information,de_list,given_data=NULL,NET2=NULL,method_data=1,samples,rho){
	# This function obtain two adjacent matrices when given pre-set differential expression gene list.
	# sub_information : The network information of random select network derived from the original PPI network. This input is the result of function read_net. 
	# de_list    : pre-set differential expression gene list.
	# given_data : If NULL, the function generate a simulated dataset to execute the following steps. If not, the function use the given dataset instead.
	# NET2       : If NULL ,the function compute the second network based on simulated/given dataset. If not, the function use the given adjacent matrix instead.
	#			   NOTICE: If the NET2 is given, there is no need to simulate dataset. Simulated dataset is just used to compute the corresponding NET2.
	
	# method_data: The way of generating the simulation dataset. The first method uses a easier process with a fixed covariance matrix, whereas the second method 
	#				consider the network information in constructing the covariance matrix and use a additional parameter 'vars' to control the variances. The third method simulates
	#               the circumstance that the single node score is low whereas the subnet's overall score is high.
	# samples    : The number of samples in simulated dataset.
	# rho        : Parameter to control the differential expression degree of simulated dataset.
	
	library(MASS)
	library(matrixcalc)
	library(mpmi)
	library(Matrix)	
	source("../Codes/Functions/neighbour_search.r")
	
	p <- length(de_list)												# number of pre-set differential expression nodes.
	l <- sub_information$size[1]										# number of random selected network nodes.
	remain  <- setdiff(sub_information$node,de_list)
	mapping <- c(de_list,remain)										# Mapping the original node to a tractable matrix form

	
	# Create simulated dataset with corresponding dimension. The first p-th features stand for the differential expression nodes.
	half <- samples/2
	if (class(given_data)=="NULL"){
		dataset <- matrix(0,samples,l,dimnames=list(paste("sample",1:samples,sep=""),paste("node",1:l,sep="")))	
		
		index <- NULL
		for (i in 1:l){
			index[i] <- which(rownames(sub_information$adj_matrix) == mapping[i])
		}
		vars  <- 1
		sigma <- matrix(0)
		while(!is.positive.definite(sigma)){
			vars  <- vars + 1 
			sigma <- sub_information$adj_matrix[index,index]						# Construct the correlation matrix of the distribution.
			sigma[which(sigma == 1)] <- rnorm(length(which(sigma == 1)),4,1)		# The correlation matrix have a higher correlation within adjacent nodes.
			sigma[which(sigma == 0)] <- rnorm(length(which(sigma == 0)),2,1)		# The correlation matrix have a lower  correlation within non-adjacent nodes.
			diag(sigma) <- rnorm(l,vars,1)
			sigma <- (sigma + t(sigma))/2
		}
		multi_mean <- rnorm(l,5,1)
		dataset <- mvrnorm(samples,multi_mean,sigma)
		if (method_data == 1){
			dataset[1:half,1:p] <- dataset[1:half,1:p] * rnorm(half*p,rho,0.1)
		}
		if (method_data == 2){
			ranges  <- ceiling(samples/(2*p))
			lower   <- 1
			upper   <- ranges
			for (i in 1:p){
				if (upper <= half){
					dataset[lower:upper,i] <- dataset[lower:upper,i] * rnorm(length(dataset[lower:upper,i]),rho,0.1)
					lower <- lower + ranges
					upper <- upper + ranges
				}
				else{
					if (lower <= half){
						dataset[c(lower:half,1:(upper-half)),i] <- dataset[c(lower:half,1:(upper-half)),i] * rnorm(length(dataset[c(lower:half,1:(upper-half)),i]),rho,0.1)
					}else{
						dataset[1:(upper-half),i] <- dataset[1:(upper-half),i] * rnorm(length(dataset[1:(upper-half),i]),rho,0.1)
					}
					lower <- upper - half  + 1
					upper <- lower + ranges - 1
				}
			}
		}
		if (method_data == 3){			
			a1 <- 1:floor(half/4);						b1 <- 1:floor(p/4)
			a2 <- (floor(half/4)+1):floor(half/2);		b2 <- (floor(p/4)+1):floor(p/2)
			a3 <- (floor(half/2)+1):floor(3*half/4);	b3 <- (floor(p/2)+1):floor(3*p/4)
			a4 <- (floor(3*half/4)+1):half;				b4 <- (floor(3*p/4)+1):p
			dataset[a1,b1] <- dataset[a1,b1] * rnorm(length(a1)*length(b1),rho,0.1)
			dataset[a2,b2] <- dataset[a2,b2] * rnorm(length(a2)*length(b2),rho,0.1)
			dataset[a3,b3] <- dataset[a3,b3] * rnorm(length(a3)*length(b3),rho,0.1)
			dataset[a4,b4] <- dataset[a4,b4] * rnorm(length(a4)*length(b4),rho,0.1)
		}
		rownames(dataset) <- paste("sample",1:samples,sep="")
		colnames(dataset) <- mapping
	}else {
		dataset <- given_data
	}
#	print("Step3 finished")
	

	# Construct two adjacency matrix of a directed weighted network which contains the information of the defined objective function.
	label <- c(rep(1,half),rep(2,half))
	network1  <- sub_information$adj_matrix[mapping,mapping]
	if (class(NET2) == "NULL"){
		MI1 <- mminjk(dataset, as.matrix(as.numeric(label)), level = 0L, na.rm = FALSE)
		MI2 <- Matrix(0,l,l,dimnames=list(colnames(dataset),colnames(dataset)),sparse=TRUE)
		for (i in 1:l){
			dataset_tmp <- (dataset[,i:l] + dataset[,i])/sqrt(2)
			MI2[i:l,i] <- mminjk(as.matrix(dataset_tmp), as.matrix(as.numeric(label)), level = 0L, na.rm = FALSE)
		}
		MI2 <- MI2 + t(MI2)
		diag(MI2) <- MI1
		
		network2 <- MI2-as.numeric(MI1)
		ind <- which(network2 <=0)
		network2[ind] <- 0
		network2 <- as(network2,"dgCMatrix")
	}else{
		network2 <- NET2
	}
#	print("Step4 finished")
	
	PCC <- NULL
	for (i in 1:l){
		PCC[i] <- cor(dataset[,i],label,method="pearson")
	}
	
	return(list(
		network1 = network1,
		network2 = network2,
		dataset  = dataset,
		MI	     = MI1,
		PCC      = PCC
		))
}
