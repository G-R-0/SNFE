neighbour_search <- function(NET,start_node,k){	
	# This function search the neighbour set of input search node at most k-steps reaching in a undirected unweighed network.
	# NET : The adjacent matrix of current network.
	# node: The start searching node.
	# k   : The parameter control the search range.

	set <- paste("neighb_set",1:k,sep='')
	result <- list()
	search_set <- start_node
	finish_set <- start_node
	
	for (p in 1:k){
		if (length(search_set) == 0){
			return(result)
		}
		for (i in 1:length(search_set)){
			result[[set[p]]] <- union(result[[set[p]]],setdiff(names(which(NET[search_set[i],] == 1)),finish_set))
		}
		search_set <- result[[set[p]]]
		finish_set <- union(finish_set,search_set)
	}
	return(result)
}
