connected_component <- function(NET,pris=FALSE){
	source("../Codes/Functions/neighbour_search.R")
	
	nodes <- colnames(NET)
	l     <- length(nodes)
	
	distance_matrix <- matrix(Inf,l,l,dimnames=list(nodes,nodes))	# The distance matrix of current network (NET).
	for (i in 1:l){
		if (pris == TRUE){
			if (i%%10==0){
				print(i)
			}
		}
		dpar <- 1
		node <- nodes[i]
		result  <- neighbour_search(NET,node,10000)					# Contains the full distance information of search node.
		
		nset <- length(result[[dpar]])								# The number of nodes whose distance to search node is dpar (d-order neighbour number).
		while (nset != 0){
			arr_ind <- matrix(as.character(c(rep(node,nset),result[[dpar]])),nset,2)
			distance_matrix[arr_ind] <- dpar
			
			dpar <- dpar + 1
			nset <- length(result[[dpar]])
		}
	}
	diag(distance_matrix) <- 0										# Distance of nodes to itself is zero.

	con_component <- list()
	con_component[[1]] <- names(which(distance_matrix[nodes[1],] < Inf))
	k <- 2
	for (i in 2:l){
		if (pris == TRUE){
			if (i%%10==0){
				print(i)
			}
		}
		tmp_set <- names(which(distance_matrix[nodes[i],] < Inf))
		index   <- NULL
		for (j in 1:length(con_component)){
			index[j] <- setequal(tmp_set,con_component[[j]])			
		}
		if (all(index == FALSE)){
			con_component[[k]] <- tmp_set
			k <- k + 1
		}
	}
	result <- list(distance_matrix = distance_matrix, con_component = con_component)
	return(result)
}
