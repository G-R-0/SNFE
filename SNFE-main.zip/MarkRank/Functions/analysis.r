analysis <- function(A1,A2,train_data,train_y,test_data,test_y,first,task_part,orilabel = FALSE,classifier = "randomforest"){
	library(mpmi)													
	library(randomForest)
	library(pROC)
	l <- ncol(train_data)
	
	# TASK1: Training dataset size increasing analysis.
	if (task_part == 1){							
		value <- list()
		for (v in 1:8){								
			value[[v]] <- 0									# Each alternative method.
		}
		value[[1]] <- as.vector(mminjk(as.matrix(train_data), as.matrix(train_y), level = 0L, na.rm = FALSE))	# Mutual information
		for (p in 1:l){
			t1  <- train_data[which(train_y==0),p]
			t2  <- train_data[which(train_y==1),p]
			value[[2]][p] <- t.test(t1,t2)$p.value											# Student t-test.
			if (all(orilabel != FALSE)){													# Using the original label to compute the PCC.
				value[[3]][p] <- cor(train_data[,p],orilabel,method="pearson")				# Pearson  correlation coefficient.
			}else{																			# Using the 0-1 binary label to compute the PCC.
				value[[3]][p] <- cor(train_data[,p],as.numeric(train_y),method="pearson")	
			}
			value[[4]][p] <- cor(train_data[,p],as.numeric(train_y),method="spearman")		# Spearman correlation coefficient.
			value[[5]][p] <- mean(t1)/mean(t2) - 1											# Fold change ratio.
		}
		score <- solve_equation(A1,A2,E_value=abs(value[[3]]),alpha=0.8,lamda=0.2,Plot=FALSE)		
		value[[6]] <- score$NetRank															# NetRank score.
		value[[7]] <- score$NetRank2														# NetRank with alpha=0.2 score.		
		value[[8]] <- score$MarkRank 														# MarkRank score.
		svalue <- list();feature <- list();tra_set <- list();model <- list();predres <- list()
		result <- matrix(0,8,4,dimnames=list(c("MI","t-test","PCC","SCC","FC","NetRank","NetRank2","MarkRank"),c("OOB_acc","Pre_acc","OOB_auc","Pre_auc")))
		for (v in 1:8){
			names(value[[v]]) <- colnames(train_data)
			if (v == 2){
				svalue[[v]] <- sort(value[[v]],decreasing=FALSE,index.return=TRUE)
			}else{
				svalue[[v]] <- sort(value[[v]],decreasing=TRUE,index.return=TRUE)			# Sorted value of each alternative method.
			}
			feature[[v]] <- names(value[[v]][svalue[[v]]$ix[1:first]])						# First is a fixed feature number.
			tra_set[[v]] <- train_data[,feature[[v]],drop=FALSE]
			
			if (classifier == "randomforest"){
				model[[v]]  <- randomForest(tra_set[[v]],as.factor(train_y),ntree=1000,localImp=TRUE,proximity=TRUE)
				result[v,1] <- sum(model[[v]]$predicted == train_y)/length(train_y)											# OOB estimate of accuracy 
				result[v,2] <- sum(predict(model[[v]],test_data[,feature[[v]]],type="response") == test_y)/length(test_y)	# Predict accuracy
				result[v,3] <- roc(train_y,model[[v]]$votes[,1])$auc 														# OOB estimate AUC
				if (length(table(test_y)) == 1){
					result[v,4] <- 1
				}else{
					result[v,4] <- roc(test_y,predict(model[[v]],test_data[,feature[[v]]],type="prob")[,1])$auc 			# Predict AUC
				}
			}
			if (classifier == "svm"){
				library(e1071)
				model[[v]]  <- svm(tra_set[[v]],as.factor(train_y),scale=FALSE,kernel="radial",gamma=0.01,cost=100,type="C-classification",probability = TRUE) 
				#model[[v]]  <- svm(tra_set[[v]],as.factor(train_y),scale=FALSE,kernel="linear",cost=1000,type="C-classification",probability = TRUE) 
				pred1 <- predict(model[[v]],tra_set[[v]],probability = TRUE)
				pred2 <- predict(model[[v]],test_data[,feature[[v]]],probability = TRUE)
				result[v,1] <- sum(pred1 == train_y)/length(train_y)														# Training accuracy 
				result[v,2] <- sum(pred2 == test_y)/length(test_y)															# Testing  accuracy
				result[v,3] <- roc(train_y,attr(pred1,"probabilities")[,1])$auc 											# Training set predicting AUC
				result[v,4] <- roc(test_y,attr(pred2,"probabilities")[,1])$auc 												# Testing  set predicting AUC
			}
			if (classifier == "naiveBayes"){
				library(e1071)
				model[[v]] <- naiveBayes(tra_set[[v]],as.factor(train_y),type='raw') 
				pred1 <- predict(model[[v]],tra_set[[v]],type='raw')
				pred2 <- predict(model[[v]],test_data[,feature[[v]]],type='raw')

				result[v,1] <- sum(as.numeric(pred1[,1] < pred1[,2]) == train_y)/length(train_y)							# Training accuracy 
				result[v,2] <- sum(as.numeric(pred2[,1] < pred2[,2]) == test_y)/length(test_y)								# Testing  accuracy
				result[v,3] <- roc(train_y,pred1[,1])$auc 																	# Training set predicting AUC
				result[v,4] <- roc(test_y,pred2[,1])$auc 																	# Testing  set predicting AUC
			}
		}
		return(result)
	}
	
	
	# TASK2: Random walk parameter alpha selection.
	if (task_part == 2){							
		PCC <- NULL
		for (p in 1:l){				
			if (all(orilabel != FALSE)){													# Using the original label to compute the PCC.
				PCC[p] <- cor(train_data[,p],orilabel,method="pearson")						# Pearson  correlation coefficient.
			}else{																			# Using the 0-1 binary label to compute the PCC.
				PCC[p] <- cor(train_data[,p],as.numeric(train_y),method="pearson")	
			}
		}
		names(PCC)  <- colnames(train_data)
		
		alpha  <- seq(0.1,0.9,0.1)
		tmpres <- matrix(0,4,length(alpha),dimnames=list(c("OOB_acc","Pre_acc","OOB_auc","Pre_auc"),alpha))
		result <- list("MarkRank"=tmpres,"NetRank"=tmpres)
		for (m in 1:length(alpha)){			 
			score <- solve_equation(A1,A2,E_value=abs(PCC),alpha=alpha[m],lamda=0.2,Plot=FALSE)
			solution_MarkRank <- score$MarkRank												# MarkRank method
			solution_NetRank  <- score$NetRank												# NetRank method
			names(solution_MarkRank) <- colnames(train_data)
			names(solution_NetRank ) <- colnames(train_data)
			sMarkRank <- sort(solution_MarkRank,decreasing=TRUE,index.return=TRUE)
			sNetRank  <- sort(solution_NetRank ,decreasing=TRUE,index.return=TRUE)
			MarkRank_feat  <- names(solution_MarkRank[sMarkRank$ix[1:first]])
			NetRank_feat   <- names(solution_NetRank [sNetRank$ix[1:first]]) 
			train_MarkRank <- train_data[,MarkRank_feat,drop=FALSE]
			train_NetRank  <- train_data[,NetRank_feat,drop=FALSE]
			
			model1 <- randomForest(train_MarkRank,as.factor(train_y),ntree=1000,localImp=TRUE,proximity=TRUE)
			model2 <- randomForest(train_NetRank ,as.factor(train_y),ntree=1000,localImp=TRUE,proximity=TRUE)
			result$MarkRank[1,m] <- sum(model1$predicted == train_y)/length(train_y)							# OOB estimate of accuracy 
			result$MarkRank[2,m] <- sum(predict(model1,test_data,type="response") == test_y)/length(test_y)		# Predict accuracy
			result$MarkRank[3,m] <- roc(train_y,model1$votes[,1])$auc 											# OOB estimate AUC
			result$MarkRank[4,m] <- roc(test_y,predict(model1,test_data,type="prob")[,1])$auc 					# Predict AUC
			result$NetRank[1,m] <- sum(model2$predicted == train_y)/length(train_y)								# OOB estimate of accuracy 
			result$NetRank[2,m] <- sum(predict(model2,test_data,type="response") == test_y)/length(test_y)		# Predict accuracy
			result$NetRank[3,m] <- roc(train_y,model2$votes[,1])$auc 											# OOB estimate AUC
			result$NetRank[4,m] <- roc(test_y,predict(model2,test_data,type="prob")[,1])$auc 					# Predict AUC
		}
		return(result)
	}


	# TASK3: Random walk parameter lambda selection.
	if (task_part == 3){		
		PCC <- NULL
		for (p in 1:l){				
			if (all(orilabel != FALSE)){													# Using the original label to compute the PCC.
				PCC[p] <- cor(train_data[,p],orilabel,method="pearson")						# Pearson  correlation coefficient.
			}else{																			# Using the 0-1 binary label to compute the PCC.
				PCC[p] <- cor(train_data[,p],as.numeric(train_y),method="pearson")	
			}
		}
		names(PCC)  <- colnames(train_data)
		
		lambda <- seq(0.1,0.9,0.1)
		tmpres <- matrix(0,4,length(lambda),dimnames=list(c("OOB_acc","Pre_acc","OOB_auc","Pre_auc"),lambda))
		result <- list("MarkRank"=tmpres,"NetRank"=tmpres[,1])

		solution_NetRank <- solve_equation(A1,A2,E_value=abs(PCC),alpha=0.8,lamda=1,Plot=FALSE)$NetRank		# NetRank method
		names(solution_NetRank) <- colnames(train_data)
		sNetRank <- sort(solution_NetRank,decreasing=TRUE,index.return=TRUE)
		NetRank_feat  <- names(solution_NetRank[sNetRank$ix[1:first]])
		train_NetRank <- train_data[,NetRank_feat,drop=FALSE]
		model2 <- randomForest(train_NetRank,as.factor(train_y),ntree=1000,localImp=TRUE,proximity=TRUE)
		result$NetRank[1] <- sum(model2$predicted == train_y)/length(train_y)									# OOB estimate of accuracy 
		result$NetRank[2] <- sum(predict(model2,test_data,type="response") == test_y)/length(test_y)			# Predict accuracy
		result$NetRank[3] <- roc(train_y,model2$votes[,1])$auc 													# OOB estimate AUC
		result$NetRank[4] <- roc(test_y,predict(model2,test_data,type="prob")[,1])$auc 							# Predict AUC
		
		for (m in 1:length(lambda)){
			solution_MarkRank <- solve_equation(A1,A2,E_value=abs(PCC),alpha=0.8,lamda=lambda[m],Plot=FALSE)$MarkRank	# MarkRank method
			names(solution_MarkRank) <- colnames(train_data)
			sMarkRank <- sort(solution_MarkRank,decreasing=TRUE,index.return=TRUE)
			MarkRank_feat  <- names(solution_MarkRank[sMarkRank$ix[1:first]])
			train_MarkRank <- train_data[,MarkRank_feat,drop=FALSE]
			
			model1 <- randomForest(train_MarkRank,as.factor(train_y),ntree=1000,localImp=TRUE,proximity=TRUE)
			result$MarkRank[1,m] <- sum(model1$predicted == train_y)/length(train_y)							# OOB estimate of accuracy 
			result$MarkRank[2,m] <- sum(predict(model1,test_data,type="response") == test_y)/length(test_y)		# Predict accuracy
			result$MarkRank[3,m] <- roc(train_y,model1$votes[,1])$auc 											# OOB estimate AUC
			result$MarkRank[4,m] <- roc(test_y,predict(model1,test_data,type="prob")[,1])$auc 					# Predict AUC
		}
		return(result)
	}
}
