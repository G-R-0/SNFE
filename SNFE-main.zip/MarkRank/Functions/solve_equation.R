solve_equation <- function(A1,A2,E_value,alpha=0.8,lamda=0.2,eps=1e-5,PCC=NULL,MI=NULL,Plot=TRUE){
	# The input A = lamda*A1 + (1-lamda)*A2. The coefficient matrix A1 and A2 are derived from NET1 and NET2 (the adjacent matrix of original PPI network and the constructed
	# directed weighted network) respectively.
	# The matrix equation is : (I-alpha*A)*R = (1-alpha)*E, where the I is n*n unit matrix.
	# Solving the final matrix equation by iterative method or matrix inversion method.

	# E_value : Contains some prior information about the importance of nodes.
	# alpha   : The convex combination coefficient of network effect and prior information vector E.
	# lamda   : The convex combination coefficient of two network effects.
	# eps     : The cut-off value of the iteration solving method.
	# MI      : The original single node mutual information of dataset computed from the function get_two_net2 with parameter analysis == TRUE.
	
	A  <- lamda*A1 + (1-lamda)*A2
	n  <- nrow(A)

	R1 <- as.matrix(runif(n))
	R2 <- as.matrix(runif(n))
	tm <- 1
	while (sum(abs(R1-R2)) >= eps){
		tm <- tm + 1
		R1 <- R2
		R2 <- alpha*A%*%R1 + (1-alpha)*E_value
	}
	R <- R2/sum(R2)
	
	S1 <- as.matrix(runif(n))
	S2 <- as.matrix(runif(n))
	tm <- 1
	while (sum(abs(S1-S2)) >= eps){
		tm <- tm + 1
		S1 <- S2
		S2 <- alpha*A1%*%S1 + (1-alpha)*E_value
	}
	S <- S2/sum(S2)

	U1 <- as.matrix(runif(n))
	U2 <- as.matrix(runif(n))
	tm <- 1
	while (sum(abs(U1-U2)) >= eps){
		tm <- tm + 1
		U1 <- U2
		U2 <- 0.2*A1%*%U1 + (1-0.2)*E_value
	}
	U <- U2/sum(U2)
	
	if (Plot == TRUE){
		par(mfrow=c(2,2))
		plot  (R,pch=16,col=3,cex=1,ylim=c(0,max(R)+0.01))					# The final solution.
		legend("topright",pch=16,col=3,legend="MarkRank")
		lines (c(p,p),c(0,1),col=9,lwd=2)
		plot  (S,pch=16,col=4,cex=1,ylim=c(0,max(S)+0.01))					# Solution just using NET1
		legend("topright",pch=16,col=4,legend="NetRank")
		lines (c(p,p),c(0,1),col=9,lwd=2)
		
		plot  (abs(PCC),pch=16,col=2,cex=1,ylim=c(0,max(abs(PCC))+0.01))	# The contribution of network1. 
		legend("topright",pch=16,col=2,legend="PCC")
		lines (c(p,p),c(0,1),col=9,lwd=2)
		
		plot  (MI,pch=16,col=8,cex=1,ylim=c(0,max(MI)+0.01))				# The original mutual information of dataset. 
		legend("topright",pch=16,col=8,legend="MI")
		lines (c(p,p),c(0,1),col=9,lwd=2)
	}
	return(list(MarkRank=as.vector(R),NetRank=as.vector(S),NetRank2=as.vector(U)))
}

	